# chhachh — native Android shell

This Android application opens `https://chhachh.com/` in a native WebView.
There is **no native top progress/loading bar**. It keeps the website's own circular loader unchanged.
The visible app name is `chhachh`, and the launcher icon is based on the original supplied jelly emblem.

## Included
- HTTPS-only home origin; external URLs are handed to a browser or relevant application.
- Photo/video file picker and camera capture with Android MediaStore; microphone and camera permissions are requested when the trusted site needs them.
- Inline autoplay video, full-screen video, Android Back navigation, download handling, retry UI for network errors.
- Native status bar and navigation bar with white background, without additional browser chrome.
- No ad SDK, analytics SDK, JavaScript interface, or site-side CSS/JS overlays.
- PWA install invitation can be hidden inside this app using the accompanying **one-source-owner** website ZIP, which identifies the native app by its User-Agent suffix.

## Build (computer)
Open this source in Android Studio with JDK 17 and Android SDK 35, or run `gradle :app:assembleDebug` with Gradle 8.11.1.

## Build without computer (GitHub Actions)
Create a private GitHub repository, upload these source files retaining the folder structure, and run **Actions → Build chhachh Android APK → Run workflow**. Download `chhachh-debug-apk` from the successful run. A debug APK is for testing only; a properly signed release APK/AAB and Play Store compliance testing are separate tasks.

## Integration / deployment
Deploy the provided `MyChhachh_V97_323_Web_Native_Install_Detection.zip` to your existing Cloudflare Pages project, after a deployment backup. It changes only the native install detection within the existing PWA controller; it does not alter the website's theme, media upload pipeline or rounded loader. Without that deployment the website may show its PWA install offer inside the native APK.

## Important test requirements
This environment lacks Android SDK and device/emulator access, so **the APK has not been compiled or tested on actual Android devices**. Before any public release, test Android 10–16, video upload and compressed playback, media capture, face verification, permissions, logout/session continuity, downloads, navigation and error recovery. Some features may differ between Chrome and system WebView; do not release until verified.

The browser-installed PWA is a separate install type. Installing this APK will not silently replace the PWA. Users must install it via its own APK or app-store listing.
